﻿
using var game = new HPScreen.ScreenSaver();
game.Run();
